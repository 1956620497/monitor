package c.e.config;

import c.e.entity.RestBean;
import c.e.entity.dto.Account;
import c.e.entity.vo.response.AuthorizeVo;
import c.e.filter.JWTAuthorizeFilter;
import c.e.service.AccountService;
import c.e.utils.JWTUtils;
import com.fasterxml.jackson.databind.util.BeanUtil;
import jakarta.annotation.Resource;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.io.IOException;
import java.io.PrintWriter;

@Configuration
public class SecurityConfiguration {

    @Resource
    JWTUtils utils;

    //jwt验证过滤器
    @Resource
    JWTAuthorizeFilter jwtAuthorizeFilter;

    @Resource
    AccountService service;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .authorizeHttpRequests(conf -> conf
                        .requestMatchers("/api/auth/**","/error").permitAll()     //允许关于/api/auth/**的请求   .permitAll()允许所有对于这个接口的请求
                        .anyRequest().authenticated()   //其他的请求必须验证之后才允许访问    所有的请求只要验证通过就能访问
                )
                .formLogin(conf -> conf
                        .loginProcessingUrl("/api/auth/login")   //设置登录接口
                        .failureHandler(this::onAuthenticationFailure)    //登录失败的处理
                        .successHandler(this::onAuthenticationSuccess)   //成功之后怎么处理
                )
                .logout(conf -> conf
                        .logoutUrl("/api/auth/logout")   //退出登录接口
                        .logoutSuccessHandler(this::onLogoutSuccess)  //退出接口的处理
                )
                .exceptionHandling(conf -> conf
                        .authenticationEntryPoint(this::onUnauthorized)  //没有登录时的处理
                        .accessDeniedHandler(this::onAccessDeny)  //没有权限时的处理
                )
                .csrf(AbstractHttpConfigurer::disable)  //开启csrf防护
                .sessionManagement(conf -> conf
                        //因为是权限处理交给JWT控制，这里将sessionManagement改为无状态，让security不去触发session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS) //sessionCreationPolicy()这个方法用于设置session的状态
                )
                .addFilterBefore(jwtAuthorizeFilter, UsernamePasswordAuthenticationFilter.class) //将自己定义的过滤器加入进去并且放在框架的过滤器之前
                .build();   //构建
    }

    //登录成功的处理
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException {
        response.setContentType("application/json;charset=utf-8"); //改变编码
        User user = (User)authentication.getPrincipal();//能直接拿到用户的详细信息
        //从数据库中查询一下用户信息
        Account account = service.findAccountByNameOrEmail(user.getUsername());

        String token = utils.createJwt(user,account.getId(),account.getUsername()); //将用户信息通过JWT加密

//        AuthorizeVo vo = new AuthorizeVo();
//        AuthorizeVo vo = account.asViewObject(AuthorizeVo.class);
        /*
        将dto对象的数据直接存到VO里
         */
//        BeanUtils.copyProperties(account,vo);

//        vo.setExpire(utils.expireTime());       //用于设置过期时间的值
        //vo.setRole(account.getRole());        //这个属性表示角色
//        vo.setToken(token);     //这个属性表示令牌
        //vo.setUsername(account.getUsername());   //设置用户名

        AuthorizeVo vo = account.asViewObject(AuthorizeVo.class,v -> {
            v.setToken(token);
            v.setExpire(utils.expireTime());
        });

        response.getWriter().write(RestBean.success(vo).asJsonString()); //转换为json格式返回
    }


    //登录失败的处理
    public void onAuthenticationFailure(HttpServletRequest request,
                                        HttpServletResponse response,
                                        AuthenticationException exception) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.unauthorized(exception.getMessage()).asJsonString());
    }


    //退出登录的接口
    public void onLogoutSuccess(HttpServletRequest request,
                                HttpServletResponse response,
                                Authentication authentication) throws IOException, ServletException {
        /**
         * jwt退出登录时该令牌依然是有效的，所以一定要把令牌拉入黑名单才能消除安全隐患         拉黑功能使用Redis来实现
         */
        response.setContentType("application/json;charset=utf-8");
        PrintWriter writer = response.getWriter();
        String authorization = request.getHeader("Authorization");
        if (utils.invalidateJwt(authorization)){
            writer.write(RestBean.success().asJsonString());
        }else{
            writer.write(RestBean.failure(400,"退出登录失败").asJsonString());
        }
    }

    //没有登录时的处理
    public void onUnauthorized(HttpServletRequest request,
                               HttpServletResponse response,
                               AuthenticationException exception) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.unauthorized(exception.getMessage()).asJsonString());
    }

    //登录了没有权限时的处理
    public void onAccessDeny(HttpServletRequest request,
                             HttpServletResponse response,
                             AccessDeniedException exception) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.forbidden(exception.getMessage()).asJsonString());
    }

}
