package c.e.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//配置消息队列    邮箱的
@Configuration
public class RabbitConfiguration {

    //注册消息队列
    @Bean("emailQueue")
    public Queue emailQueue(){
        return QueueBuilder
                .durable("mail")     //队列名字
                .build();
    }

}
