package c.e.entity.vo.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

//验证注册时上传的参数
@Data
public class EmailRegisterVO {

    @Email    //邮箱验证
    @Length(min = 6)
    String email;
    @Length(max = 6,min = 6)  //验证码只能是6位
    String code;
    @Pattern(regexp = "^[a-zA-Z0-9\\u4e00-\\u9fa5]+$")  //不允许有特殊字符
            @Length(min = 3,max = 10)
    String username;
    @Length(min = 6,max = 20)
    String password;

}
